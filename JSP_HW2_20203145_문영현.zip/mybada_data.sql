USE mybada;

INSERT INTO puser VALUES("james", "1111", "이정아", now());
INSERT INTO puser VALUES("apple", "2222", "정일용", now());
INSERT INTO puser VALUES("water", "3333", "김판구", now());
INSERT INTO puser VALUES("melon", "4444", "모상만", now());
INSERT INTO puser VALUES("banana", "5555", "신석주", now());
INSERT INTO puser VALUES("lemon", "6666", "정현숙", now());
INSERT INTO puser VALUES("kang", "7777", "강문수", now());
INSERT INTO puser VALUES("yang", "8888", "양희덕", now());
INSERT INTO puser VALUES("sim", "9999", "심재홍", now());
INSERT INTO puser VALUES("jeoung", "1010", "정호엽", now());
INSERT INTO puser VALUES("che", "1011", "최우열", now());
INSERT INTO puser VALUES("chun", "1012", "전찬준", now());


INSERT INTO pfeed(id, content) VALUES("banana", "홈페이지추가");
INSERT INTO pfeed(id, content) VALUES("meleon", "홈페이지삭제");
INSERT INTO pfeed(id, content) VALUES("spider", "홈페이지수정");
INSERT INTO pfeed(id, content) VALUES("bug", "조선대소개");
INSERT INTO pfeed(id, content) VALUES("cs", "조대컴퓨터공학과알림");